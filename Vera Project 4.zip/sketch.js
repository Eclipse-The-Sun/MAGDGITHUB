var haba = 400;
var shincho = 400;
var x = 40;
var value = 0;

function setup() {
  createCanvas(haba, shincho);
  frameRate(30);
}

function draw() {
  background(220);
  if (keyIsPressed === true) {
    fill(0);
  } else {
    fill(255);
  }
  ellipse(haba / 2, shincho / 2, haba / 3, shincho / 3);
  for(var i = 0; i < 11; i++) {
    line(x-2, 0 ,x+2, shincho );
    x = 40 * i;
  }
  x = 40;
  
  if(value == 1){
    for(var v = 0; v < 11; v++) {
      line(0, x-2 ,haba, x+2 );
      x = 40 * v;
    }
  }
}

function mouseClicked() {
    if (value == 0) {
      value = 1;
      return false;
    } else {
      value = 0;
    }
}