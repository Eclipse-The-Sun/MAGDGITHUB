var z = 75;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);

  if (mouseIsPressed === true) {
    for(var i = 0; i < 5; i++){
    ellipse(mouseX, mouseY, z, z);
    ellipse(mouseX-50, mouseY, z, z); 
    ellipse(mouseX+50, mouseY, z, z);
    ellipse(mouseX, mouseY-50, z, z);
    translate(14,14);
    }
  } else {
    scale(0.5);
    ellipse(mouseX,mouseY,z,z);
    push();
    rotate(PI/5);
    rect(mouseX, mouseY, z, z);
  }
   print(mouseIsPressed);
  describe(`black 50-by-50 rect becomes ellipse with mouse click/press.
    fuchsia background.`);
}