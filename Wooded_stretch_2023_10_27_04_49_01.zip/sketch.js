function setup() {
  createCanvas(400, 400);
}

var x = [];
var y = [];
var z = [];

function draw() {
  background(220);
  
  for (var i = 0; i < 30; i++) {
	x[i] = random(0, 400); 
    print(x[i]);
    quad(x[i], x[i], x[i] + 5, x[i] - 5, x[i] + 10, x[i] -10, x[i] + 15, x[i] - 15);
    for (var o = 0; o < 100; o++){
      y[o] = mouseX;
      for(var b = 0; b < 100; b++){
        z[b] = mouseY;
      }
      circle(y, z, 15)
  }
	}
  
}